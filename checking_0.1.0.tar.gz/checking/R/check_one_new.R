check_one = function(loc1,hw)
{
  #loc1 = "D:/dataming_hw/StudentSHEET.xlsx"
  #hw = "hw1"
  #��Ҫ��װ��openxlsx
  library(openxlsx)
  #loc1 ,ѧ��excel���ı���·��
  #�������ѧ��excel��Ŀ¼�ı���·��
  loc_split = unlist(strsplit(loc1,split='/'))
  loc_split =loc_split[-length(unlist(strsplit(loc1,split='/')))]
  loc2 = paste(loc_split,collapse = '/')
  stu = read.xlsx(loc1)
  # hw = "hw1"  #�ڼ�����ҵ
  loc = paste(loc2,hw,sep = '/')
  setwd(loc)
  namelist = dir()
  list_test =list()
  for (i in 1:(length(namelist)))
  {
    temp = namelist[i]
    temp_list = unlist(strsplit(temp,split=NULL))
    for (j in 1:(length(temp_list)))
    {
      options(warn=-1) #�������о���
      if(
        (is.na(as.numeric(temp_list[j]))==FALSE)&
        (is.na(as.numeric(temp_list[j+1]))==FALSE)&
        (is.na(as.numeric(temp_list[j+2]))==FALSE)
      )
      {
        temp2 =""
        for (k in 1:10)
        {
          temp2 =paste0(temp2,temp_list[j])
          j = j+1
        }
        list_test[i] = temp2
        break
      }
    }
  }
  vec = c()
  for (i in 1:length(row(stu[2])))
    {
    if (stu[2][i,1] %in% list_test == FALSE)
      {
      vec = c(vec,(stu[1][i,1]))
      }
    }
  return(vec)
}

#��Ҫ����ȫ����ҵ���ļ���hw1��
#��ѧ����StudentSHEET.xlsx��ͬһ���ļ���dataming_hw��


#���б�����ǰ��
#�Ƚ�name.bat����������ȫ����ҵ���ļ���hw1��,˫������,
#������һ��LIST.txt(�����ļ����ڵ������ļ���)


c = check_one("D:/dataming_hw/StudentSHEET.xlsx","hw1")
c


ck1.1 = function(loc,op){
  clg = read.csv(loc,header = T)
  if (FALSE %in% op==clg)
  { retrun("Incorrect")
  }
  else{return("Correct")
  }
}


ck1.2 = function(loc,op1,op2,op3){
  clg = read.csv(loc,header = T)
  if(class(clg) ==op1 &
     dim(clg) ==op2 &
     head(clg) == op3)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck1.3 = function(loc,op1){
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  if(clg ==op1)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

ck1.4 = function(loc,op1){
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  if(summary(clg) == op1)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck1.5 = function(loc,ip1){
  row = row(ip1)[,1]
  col = col(ip1)[1,]
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  clg1 = clg[row,col] #stu answer
  clg2 = clg[, 1:5] #true answer
  if(clg1 == clg2)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}




#ck1.6,ck1.8,1.9 ���б�׼��֪������ƶ�





ck1.7 = function(loc,op1){
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  Elite <- rep("No", nrow(clg))
  Elite[clg$Top10perc >= 50] <- "Yes"
  Elite <- as.factor(Elite)
  clg <- data.frame(clg, Elite)
  if(clg == op1)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

overallscore.1 = function(loc,op0,op1,op2,op3,op4,op5,op6,ip1){
  score = 0
  ans = c(ck1.1(loc,op0),
          ck1.2(loc,op1,op2,op3),
          ck1.3(loc,op4),
          ck1.4(loc,op5),
          ck1.5(loc,ip1),
          ck1.7(loc,op6))
  for (i in 1:length(ans)){
    if(ans[i] == "Correct"){
      score = score + 10
    }
  }
  print("�÷֣�")
  return(score)
}

ck2.1 = function(loc,op0){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  # ��ȡ����,��"?"��ת��ΪNA
  auto <- na.omit(auto) # ɾ��ȱʧֵ������
  if (FALSE %in% op0==auto)
  {retrun("Incorrect")
  }
  else{return("Correct")
  }
}


ck2.2.1 = function(loc,op1)
{
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ horsepower, data = auto)

  if (FALSE %in% coef(op1)==coef(fit))
  {retrun("Incorrect")
  }
  else{return("Correct")
  }
}

ck2.2.2 = function(loc,op2)
{
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ horsepower, data = auto)
  pred = predict(fit, data.frame(horsepower = 98))
  if ((op2==pred)==FALSE)
  {retrun("Incorrect")
  }
  else{return("Correct")
  }
}

ck2.5 = function(loc,ip1){
  row = row(ip1)[,1]
  col = col(ip1)[1,]
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  auto1 = auto[row,col] #stu answer
  auto2 = auto[, 1:8] #true answer
  if(auto1 == auto2)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

ck2.6 = function(loc,op3){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  cor=cor(auto[, 1:8])
  if(cor == op3)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck2.7 = function(loc,op4){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ . - name, data = auto)
  if(coef(fit) == coef(op4))
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

ck2.8 = function(loc,op5){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ . - name + displacement:horsepower,
           data = auto)
  if(coef(fit) == coef(op5))
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck3.1 = function(loc,op)
{
  set.seed(Seed)
  auto <- read.csv(loc, header = T, na.strings = "?")
  auto <- na.omit(auto)
  mpg01 <- rep(1, nrow(auto))
  mpg01[auto[, "mpg"] >= median(auto[, "mpg"])] <- 0
  mpg01 <- as.factor(mpg01)
  auto <- auto[, -1]
  auto <- cbind(mpg01, auto)
  auto <- auto[, -9]
  if(FALSE %in% (auto == op))
  {return("Incorrect")}
  else
  {return("Correct")}

}

ck3.3 = function(loc,Seed,op1,op2)
{
  set.seed(Seed)
  auto <- read.csv(loc, header = T, na.strings = "?")
  auto <- na.omit(auto)
  mpg01 <- rep(1, nrow(auto))
  mpg01[auto[, "mpg"] >= median(auto[, "mpg"])] <- 0
  mpg01 <- as.factor(mpg01)
  auto <- auto[, -1]
  auto <- cbind(mpg01, auto)
  auto <- auto[, -9]
  train <- sample(1:nrow(auto), 200, replace = F)
  train.auto <- auto[train, ]
  test.auto <- auto[- train, ]
  if(FALSE %in% (test.auto == op2)|FALSE %in% (train.auto == op1))
  {return("Incorrect")}
  else
  {return("Correct")}
}





ck3.4567 = function(loc, Seed, ip,op, model,k)
{
  library(class)
  set.seed(Seed)
  auto <- read.csv(loc, header = T, na.strings = "?")
  auto <- na.omit(auto)
  mpg01 <- rep(1, nrow(auto))
  mpg01[auto[, "mpg"] >= median(auto[, "mpg"])] <- 0
  mpg01 <- as.factor(mpg01)
  auto <- auto[, -1]
  auto <- cbind(mpg01, auto)
  auto <- auto[, -9]
  train <- sample(1:nrow(auto), 200, replace = F)
  train.auto <- auto[train, ]
  test.auto <- auto[- train, ]
  a = train.auto[ip]
  a = cbind(train.auto["mpg01"],a)
  if(model == "logistic")
  {
    glm.fit <- glm(mpg01 ~., data = a,family = binomial)
    glm.probs <- predict(glm.fit,
                         newdata = test.auto,
                         type = "response")
    glm.preds <- rep(0, length(glm.probs))
    glm.preds[glm.probs >= 0.5] <- 1
    rate = mean(glm.preds == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}

  }else if(model == "LDA")
  {
    require(MASS)
    lda.fit <- lda(mpg01 ~., data =a)
    lda.pred <- predict(lda.fit, test.auto)
    post.pred <- rep(0, nrow(test.auto))
    post.pred[lda.pred$posterior[,"1"] >= 0.5] <- "1"
    rate =  mean(lda.pred$class == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}
  }else if(model == "QDA")
  {
    qda.fit <- qda(mpg01 ~ cylinders
                   + displacement + horsepower
                   + weight ,
                   data = train.auto)
    qda.pred <- predict(qda.fit, test.auto)
    rate = mean(qda.pred$class == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}
  }else(model == "KNN")
  {
    train.x <- train.auto[,ip]
    test.x <- test.auto[,ip]
    train.y <- train.auto[, "mpg01"]
    require(class)
    knn.pred <- knn(train.x, test.x, train.y, k = k)
    rate = mean(knn.pred == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}
  }


}


ck4.1 = function(seed,op0)
{
  library(ISLR)
  set.seed(seed)
  #summary(Default)
  idx <- sample(which(Default$default == "No"),
                500, replace = F)
  idx <- c(idx, which(Default$default == "Yes"))
  Default <- Default[idx, ]
  fit <- glm(default ~ income + balance,
             data = Default, family = binomial)
  if(coef(op0)==coef(fit))
  {
    return("Correct")}
  else
  {return("Incorrect")}

}

ck4.11 = function(sed =123)
{
  library(ISLR)
  set.seed(sed)
  #summary(Default)
  idx <- sample(which(Default$default == "No"),
                500, replace = F)
  idx <- c(idx, which(Default$default == "Yes"))
  Default <- Default[idx, ]
  return(Default)

}

ck4.21 = function(op,seed,data)
{
  Default = data
  n <- nrow(Default)
  set.seed(seed)
  index <- sample(1 : n, 400, replace = F)
  tra <- Default[index, ]
  tes <- Default[-index, ]
  glm.fit.1 <- glm(default ~ income + balance,
                   family = binomial,
                   data = tra)
  glm.probs.1 <- predict(glm.fit.1,
                         newdata = tes,
                         type = "response")
  glm.pred.1 <- rep("No", length(glm.probs.1))
  glm.pred.1[glm.probs.1 >= 0.5] <- "Yes"
  error = mean(glm.pred.1 != tes$default)
  if(op==error)
  {
    return("Correct")}
  else
  {return("Incorrect")}

}

cv_fun <- function(dat, k = 2)
{
  k =2
  n <- nrow(dat)
  index <- sample(rep(1:k, length = n), n, replace = F)
  mse <- rep(0, k)
  for(i in 1 : k) {
    train <- which(index != i)
    glm.fit <- glm(default ~ income + balance, family = binomial, data = dat, subset = train)
    glm.probs <- predict(glm.fit, newdata = dat[-train, ], type = "response")
    glm.pred <- rep("No", length(glm.probs))
    glm.pred[glm.probs >= 0.5] <- "Yes"
    mse[i] <- mean(glm.pred != dat[-train, ]$default)
  }
  cv_value <- mean(mse)
  cv_value
}

ck4.5 = function(op4,op5,op6,seed,data)
{
  Default = data
  set.seed(seed)
  if((op4 == cv_fun(Default, 2))&
     (op5 == cv_fun(Default, 5))&
     (op6 = cv_fun(Default, 10)))
  {return("Correct")}
  else
  {return("Incorrect")}

}

cv_fun.1 <- function(dat, k = 10) {
  n <- nrow(dat)
  index <- sample(rep(1:k, length = n), n, replace = F)
  mse <- rep(0, k)
  for(i in 1 : k) {
    train <- which(index != i)
    glm.fit <- glm(default ~ income + balance + student, family = binomial, data = dat, subset = train) # ??????????????????????student
    glm.probs <- predict(glm.fit, newdata = dat[-train, ], type = "response")
    glm.pred <- rep("No", length(glm.probs))
    glm.pred[glm.probs >= 0.5] <- "Yes"
    mse[i] <- mean(glm.pred != dat[-train, ]$default)
  }
  cv_value <- mean(mse)
  cv_value
}

ck4.6 = function(op,seed,data)
{
  Default = data
  set.seed(seed)
  if(op==cv_fun.1(Default))
  {
    return("Correct")}
  else
  {return("Incorrect")}
}


ck4.7 = function(op,data)
{
  Default = data
  glm.fit<- glm(default ~ income + balance,
                family = binomial,
                data = Default)
  if(coef(op)==coef(glm.fit))
  {
    return("Correct")}
  else
  {return("Incorrect")}

}

boot.fn = function(dat, index)
  return(coef(glm(default ~ income + balance, data = dat, subset = index, family = binomial)))


ck4.8 = function(op,bsp)
{
  Default = ck4.11()
  set.seed(seed)
  require(boot)
  return(boot(Default, boot.fn, bsp))

}



predict.regsubsets2 <- function(object, newdata, id) {
  formula <- as.formula(object$call[[2]])
  mat <- model.matrix(formula, newdata)
  coefi <- coef(object,id)
  xvars <- names(coefi)
  mat[, xvars] %*% coefi
}

cv.regsubsets2 <- function(formula, data, nvmax = 8, method = "exhaustive", k = 10) {
  n <- nrow(data)
  idx <- rep(1:k, length = n)
  idx <- sample(idx, n, replace = F)

  val.mat <- matrix(NA, nrow = nvmax, ncol = k)
  for(i in 1:k) {
    train <- (idx != i)
    test <- (idx == i)

    regfit.sub <- regsubsets(formula, data = data[train, ], method = method, nvmax = nvmax)
    for(j in 1:nvmax) {
      predi <- predict.regsubsets2(regfit.sub, newdata = data[test, ], id = j)
      val.mat[j, i] <- mean((predi - data[test, all.vars(formula)[1]])^2)
    }

  }
  val.err <- rowMeans(val.mat)

  val.err
}


ck5_x = function(){
  set.seed(1)
  n <- 100
  N <- 5000
  p <- 20
  beta <- rep(0, p)
  beta[c(1,2,3)] <- c(5,4,3)
  x <- matrix(rnorm(n*p), nrow = n, ncol = p)
  y <- x%*%beta + rnorm(n, 0, 2)
  x.test <- matrix(rnorm(N*p), nrow = N, ncol = p)
  y.test <- x.test %*% beta + rnorm(N, 0, 2)
  data.train <- data.frame(x, y)
  data.test <- data.frame(x.test, y.test)
  return(x)
}

ck5_y = function(){
  set.seed(1)
  n <- 100
  N <- 5000
  p <- 20
  beta <- rep(0, p)
  beta[c(1,2,3)] <- c(5,4,3)
  x <- matrix(rnorm(n*p), nrow = n, ncol = p)
  y <- x%*%beta + rnorm(n, 0, 2)
  x.test <- matrix(rnorm(N*p), nrow = N, ncol = p)
  y.test <- x.test %*% beta + rnorm(N, 0, 2)
  data.train <- data.frame(x, y)
  data.test <- data.frame(x.test, y.test)
  return(y)
}

ck5_x.test = function(){
  set.seed(1)
  n <- 100
  N <- 5000
  p <- 20
  beta <- rep(0, p)
  beta[c(1,2,3)] <- c(5,4,3)
  x <- matrix(rnorm(n*p), nrow = n, ncol = p)
  y <- x%*%beta + rnorm(n, 0, 2)
  x.test <- matrix(rnorm(N*p), nrow = N, ncol = p)
  y.test <- x.test %*% beta + rnorm(N, 0, 2)
  data.train <- data.frame(x, y)
  data.test <- data.frame(x.test, y.test)
  return(x.test)
}


ck5_datatrain = function(){
  set.seed(1)
  n <- 100
  N <- 5000
  p <- 20
  beta <- rep(0, p)
  beta[c(1,2,3)] <- c(5,4,3)
  x <- matrix(rnorm(n*p), nrow = n, ncol = p)
  y <- x%*%beta + rnorm(n, 0, 2)
  x.test <- matrix(rnorm(N*p), nrow = N, ncol = p)
  y.test <- x.test %*% beta + rnorm(N, 0, 2)
  data.train <- data.frame(x, y)
  data.test <- data.frame(x.test, y.test)
  return(data.train)
}


ck = function(op1,op2,op3,op4,method = "exhaustive")
{
  data.train = ck5_datatrain()
  x = ck5_x()
  y = ck5_y()
  p =20
  set.seed(1)
  library(leaps)
  regfit.full <- regsubsets(y~., data.train,
                            method = method,nvmax = p)
  reg.summary <- summary(regfit.full)
  cv.values <- cv.regsubsets2(y ~ ., data.train, nvmax = p,method = method)
  if((op1 == which.max(reg.summary$adjr2)&
     op2 == which.min(reg.summary$cp)&
     op3 == which.min(reg.summary$bic)&
     op4 == which.min(cv.values))==TRUE)
  {return("Correct")}
  else
  {return("Incorrect")}

}

ck2 = function(op,alpha)
{
  x = ck5_x()
  y = ck5_y()
  x.test = ck5_x.test()
  set.seed(2)
  require(glmnet)
  mod <- glmnet(x, y, alpha =alpha )
  cv <- cv.glmnet(x, y, alpha=alpha)
  pred <- predict(cv,s = "lambda.min", newx = x.test)
  if(mean((y.test - as.numeric(pred))^2) == op)
  {return("Correct")}
  else
  {return("Incorrect")}

}


ck6.2  = function(op)
{
  set.seed(2)
  library(MASS)
  fit.1 <- lm(nox ~ poly(dis, 1), data = Boston)
  fit.2 <- lm(nox ~ poly(dis, 2), data = Boston)
  fit.3 <- lm(nox ~ poly(dis, 3), data = Boston)
  fit.4 <- lm(nox ~ poly(dis, 4), data = Boston)
  fit.5 <- lm(nox ~ poly(dis, 5), data = Boston)
  fit.6 <- lm(nox ~ poly(dis, 6), data = Boston)
  fit.7 <- lm(nox ~ poly(dis, 7), data = Boston)
  fit.8 <- lm(nox ~ poly(dis, 8), data = Boston)
  fit.9 <- lm(nox ~ poly(dis, 9), data = Boston)
  fit.10 <- lm(nox ~ poly(dis, 10), data = Boston)
  result.anova <- anova(fit.1,
                        fit.2,
                        fit.3, fit.4,
                        fit.5,fit.6,
                        fit.7, fit.8, fit.9, fit.10)
  if(result.anova$RSS==op){return("Correct")}
  else{return("Incorrect")}
}


ck6.3 = function(op)
{
  if(2<=op&op<=5){return("Correct")}
  else{return("Incorrect")}
}



ck6.5 = function(op)
{
  library(MASS)
  df_vec <- 5:10
  val.err <- rep(0, length(df_vec))
  for(i in 1:length(df_vec)) {
    lm.fit <- lm(nox ~ bs(dis, df = df_vec[i]), data = Boston)
    val.err[i] <- sum(lm.fit$residuals^2)
  }
  if(op == val.err){return("Correct")}
  else{return("Incorrect")}
}



ck6.6 = function(op)
{
  library(MASS)
  set.seed(2)
  for(i in 1:length(df_vec)){
    options(warn = -1)
    glm.fit <- glm(nox ~ bs(dis, df = df_vec[i]),
                   data = Boston)
    cv.error[i] <- cv.glm(Boston, glm.fit, K = 10)$delta[1]
  }
  if(op == which.min(as.numeric(cv.error))){return("Correct")}
  else{return("Incorrect")}


}


ck6.7 = function(op1,op2,op3,op4)
{
  set.seed(2)
  require(ISLR)
  require(leaps)
  regfit.fwd <- regsubsets (Outstate ~.,
                            data = College,
                            nvmax = 17,
                            method = "forward")
  reg.summary.fwd <- summary(regfit.fwd)
  if(op1 ==which.min(reg.summary.fwd$bic)&
     op2 ==which.min(reg.summary.fwd$cp)&
     op3 ==which.max(reg.summary.fwd$adjr2)&
     op4 ==which.max(reg.summary.fwd$rsq)){return("Correct")}
  else{return("Incorrect")}

}


ck6.9 = function(op)
{
  if("perc.alumni"%in%op){return("Correct")}
  else{return("Incorrect")}
}


ck6.10 = function(op1,op2)
{
  if(op1<op2){
    return("�����˷���������op2��Ȼ����op1�𣿼���ǲ��������������")
  }
}


ck7.1 = function(op)
{
  set.seed(1)
  library(tree)
  library(randomForest)
  library(gbm)
  library(ISLR)
  train <- sample(1:dim(OJ)[1], 800, replace = F)
  if(OJ[train,]==op){return("Correct")}
  else{return("Incorrect")}
}

ck7.11 = function()
{
  set.seed(1)
  library(tree)
  library(randomForest)
  library(gbm)
  library(ISLR)
  train <- sample(1:dim(OJ)[1], 800, replace = F)
  return(train)
}


ck7.2 = function(op)
{
  library(tree)
  library(randomForest)
  library(gbm)
  library(ISLR)
  tree.OJ <- tree(Purchase ~ . , data = OJ[ck7.11(),])
  tree.pred <- predict(tree.OJ, OJ[-ck7.11(),],
                       type = "class")
  if(mean(tree.pred == OJ[-train, "Purchase"]) ==op)
  {return("Correct")}
  else{return("Incorrect")}

}



ck7.3 = function(op1,op2,op3)
{
  library(tree)
  library(randomForest)
  library(gbm)
  library(ISLR)
  set.seed(2)
  prune.OJ <- prune.misclass(op1, best = op2)
  tree.pred <- predict(prune.OJ,
                       OJ[-ck7.11(),],
                       type = "class")
  if(mean(tree.pred == OJ[-train, "Purchase"]) ==op)
  {return("Correct")}
  else{return("Incorrect")}
}


ck7.45 = function(op,op1,seed,mtry)
{
  library(tree)
  library(randomForest)
  library(gbm)
  library(ISLR)
  tr = ck7.11()
  set.seed(seed)
  mod.OJ <- randomForest(Purchase ~., data = OJ,
                         subset = tr, mtry = mtry)
  yhat.bag <- predict(mod.OJ, newdata = OJ[-tr, ])
  if((mean(yhat.bag == OJ[-tr, "Purchase"]) ==op)&
     op1 == "LoyalCH"){return("Correct")}
  else{return("Incorrect")}
}



ck7.6 = function(op1,op2,op3,seed = 5)
{
  library(tree)
  library(randomForest)
  library(gbm)
  library(ISLR)
  tr = ck7.11()
  set.seed(seed)
  OJ.tran <- OJ
  OJ.tran[, 1] <- ifelse(OJ$Purchase == "CH", 1, 0)
  boost.OJ <- gbm(Purchase ~., data = OJ.tran[tr, ],
                  distribution = "bernoulli",
                  n.trees = op1,
                  interaction.depth = op2)
  yhat.boost <- predict(boost.OJ,
                        newdata = OJ.tran[-tr, ],
                        n.trees = op1)
  yhat.boost <- 1 / (1 + exp(- yhat.boost))
  yhat.boost <- ifelse(yhat.boost > 0.5, 1, 0)
  mean(yhat.boost == OJ.tran[-train, 1])
  if(mean(yhat.boost == OJ.tran[-train, 1]) ==op3){return("Correct")}
  else{return("Incorrect")}
}

