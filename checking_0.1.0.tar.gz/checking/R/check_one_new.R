check_one = function(loc1,hw)
{
  #loc1 = "D:/dataming_hw/StudentSHEET.xlsx"
  #hw = "hw1"
  #��Ҫ��װ��openxlsx
  library(openxlsx)
  #loc1 ,ѧ��excel���ı���·��
  #�������ѧ��excel��Ŀ¼�ı���·��
  loc_split = unlist(strsplit(loc1,split='/'))
  loc_split =loc_split[-length(unlist(strsplit(loc1,split='/')))]
  loc2 = paste(loc_split,collapse = '/')
  stu = read.xlsx(loc1)
  # hw = "hw1"  #�ڼ�����ҵ
  loc = paste(loc2,hw,sep = '/')
  setwd(loc)
  namelist = dir()
  list_test =list()
  for (i in 1:(length(namelist)))
  {
    temp = namelist[i]
    temp_list = unlist(strsplit(temp,split=NULL))
    for (j in 1:(length(temp_list)))
    {
      options(warn=-1) #�������о���
      if(
        (is.na(as.numeric(temp_list[j]))==FALSE)&
        (is.na(as.numeric(temp_list[j+1]))==FALSE)&
        (is.na(as.numeric(temp_list[j+2]))==FALSE)
      )
      {
        temp2 =""
        for (k in 1:10)
        {
          temp2 =paste0(temp2,temp_list[j])
          j = j+1
        }
        list_test[i] = temp2
        break
      }
    }
  }
  vec = c()
  for (i in 1:length(row(stu[2])))
    {
    if (stu[2][i,1] %in% list_test == FALSE)
      {
      vec = c(vec,(stu[1][i,1]))
      }
    }
  return(vec)
}

#��Ҫ����ȫ����ҵ���ļ���hw1��
#��ѧ����StudentSHEET.xlsx��ͬһ���ļ���dataming_hw��


#���б�����ǰ��
#�Ƚ�name.bat����������ȫ����ҵ���ļ���hw1��,˫������,
#������һ��LIST.txt(�����ļ����ڵ������ļ���)


c = check_one("D:/dataming_hw/StudentSHEET.xlsx","hw1")
c


ck1.1 = function(loc,op){
  clg = read.csv(loc,header = T)
  if (FALSE %in% op==clg)
  { retrun("Incorrect")
  }
  else{return("Correct")
  }
}


ck1.2 = function(loc,op1,op2,op3){
  clg = read.csv(loc,header = T)
  if(class(clg) ==op1 &
     dim(clg) ==op2 &
     head(clg) == op3)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck1.3 = function(loc,op1){
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  if(clg ==op1)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

ck1.4 = function(loc,op1){
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  if(summary(clg) == op1)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck1.5 = function(loc,ip1){
  row = row(ip1)[,1]
  col = col(ip1)[1,]
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  clg1 = clg[row,col] #stu answer
  clg2 = clg[, 1:5] #true answer
  if(clg1 == clg2)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}




#ck1.6,ck1.8,1.9 ���б�׼��֪������ƶ�





ck1.7 = function(loc,op1){
  clg = read.csv(loc,header = T)
  rownames(clg) <- clg[, 1]
  clg <- clg[, -1]
  Elite <- rep("No", nrow(clg))
  Elite[clg$Top10perc >= 50] <- "Yes"
  Elite <- as.factor(Elite)
  clg <- data.frame(clg, Elite)
  if(clg == op1)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

overallscore.1 = function(loc,op0,op1,op2,op3,op4,op5,op6,ip1){
  score = 0
  ans = c(ck1.1(loc,op0),
          ck1.2(loc,op1,op2,op3),
          ck1.3(loc,op4),
          ck1.4(loc,op5),
          ck1.5(loc,ip1),
          ck1.7(loc,op6))
  for (i in 1:length(ans)){
    if(ans[i] == "Correct"){
      score = score + 10
    }
  }
  print("�÷֣�")
  return(score)
}

ck2.1 = function(loc,op0){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  # ��ȡ����,��"?"��ת��ΪNA
  auto <- na.omit(auto) # ɾ��ȱʧֵ������
  if (FALSE %in% op0==auto)
  {retrun("Incorrect")
  }
  else{return("Correct")
  }
}


ck2.2.1 = function(loc,op1)
{
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ horsepower, data = auto)

  if (FALSE %in% coef(op1)==coef(fit))
  {retrun("Incorrect")
  }
  else{return("Correct")
  }
}

ck2.2.2 = function(loc,op2)
{
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ horsepower, data = auto)
  pred = predict(fit, data.frame(horsepower = 98))
  if ((op2==pred)==FALSE)
  {retrun("Incorrect")
  }
  else{return("Correct")
  }
}

ck2.5 = function(loc,ip1){
  row = row(ip1)[,1]
  col = col(ip1)[1,]
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  auto1 = auto[row,col] #stu answer
  auto2 = auto[, 1:8] #true answer
  if(auto1 == auto2)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

ck2.6 = function(loc,op3){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  cor=cor(auto[, 1:8])
  if(cor == op3)
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck2.7 = function(loc,op4){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ . - name, data = auto)
  if(coef(fit) == coef(op4))
  {return("Correct")
  }
  else{return("Incorrect")
  }
}

ck2.8 = function(loc,op5){
  auto <- read.csv(loc,
                   header = T,
                   na.strings = "?")
  auto <- na.omit(auto)
  fit = lm(mpg ~ . - name + displacement:horsepower,
           data = auto)
  if(coef(fit) == coef(op5))
  {return("Correct")
  }
  else{return("Incorrect")
  }
}


ck3.1 = function(loc,op)
{
  set.seed(Seed)
  auto <- read.csv(loc, header = T, na.strings = "?")
  auto <- na.omit(auto)
  mpg01 <- rep(1, nrow(auto))
  mpg01[auto[, "mpg"] >= median(auto[, "mpg"])] <- 0
  mpg01 <- as.factor(mpg01)
  auto <- auto[, -1]
  auto <- cbind(mpg01, auto)
  auto <- auto[, -9]
  if(FALSE %in% (auto == op))
  {return("Incorrect")}
  else
  {return("Correct")}

}

ck3.3 = function(loc,Seed,op1,op2)
{
  set.seed(Seed)
  auto <- read.csv(loc, header = T, na.strings = "?")
  auto <- na.omit(auto)
  mpg01 <- rep(1, nrow(auto))
  mpg01[auto[, "mpg"] >= median(auto[, "mpg"])] <- 0
  mpg01 <- as.factor(mpg01)
  auto <- auto[, -1]
  auto <- cbind(mpg01, auto)
  auto <- auto[, -9]
  train <- sample(1:nrow(auto), 200, replace = F)
  train.auto <- auto[train, ]
  test.auto <- auto[- train, ]
  if(FALSE %in% (test.auto == op2)|FALSE %in% (train.auto == op1))
  {return("Incorrect")}
  else
  {return("Correct")}
}





ck3.4567 = function(loc, Seed, ip,op, model,k)
{
  set.seed(Seed)
  auto <- read.csv(loc, header = T, na.strings = "?")
  auto <- na.omit(auto)
  mpg01 <- rep(1, nrow(auto))
  mpg01[auto[, "mpg"] >= median(auto[, "mpg"])] <- 0
  mpg01 <- as.factor(mpg01)
  auto <- auto[, -1]
  auto <- cbind(mpg01, auto)
  auto <- auto[, -9]
  train <- sample(1:nrow(auto), 200, replace = F)
  train.auto <- auto[train, ]
  test.auto <- auto[- train, ]
  a = train.auto[ip]
  a = cbind(train.auto["mpg01"],a)
  if(model == "logistic")
  {
    glm.fit <- glm(mpg01 ~., data = a,family = binomial)
    glm.probs <- predict(glm.fit,
                         newdata = test.auto,
                         type = "response")
    glm.preds <- rep(0, length(glm.probs))
    glm.preds[glm.probs >= 0.5] <- 1
    rate = mean(glm.preds == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}

  }else if(model == "LDA")
  {
    require(MASS)
    lda.fit <- lda(mpg01 ~., data =a)
    lda.pred <- predict(lda.fit, test.auto)
    post.pred <- rep(0, nrow(test.auto))
    post.pred[lda.pred$posterior[,"1"] >= 0.5] <- "1"
    rate =  mean(lda.pred$class == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}
  }else if(model == "QDA")
  {
    qda.fit <- qda(mpg01 ~ cylinders
                   + displacement + horsepower
                   + weight ,
                   data = train.auto)
    qda.pred <- predict(qda.fit, test.auto)
    rate = mean(qda.pred$class == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}
  }else(model == "KNN")
  {
    train.x <- train.auto[,ip]
    test.x <- test.auto[,ip]
    train.y <- train.auto[, "mpg01"]
    require(class)
    knn.pred <- knn(train.x, test.x, train.y, k = k)
    rate = mean(knn.pred == test.auto$mpg01)
    if(rate == op)
    {return("Correct")}
    else
    {return("Incorrect")}
  }


}

