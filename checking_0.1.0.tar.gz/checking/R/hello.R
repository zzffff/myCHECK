# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

#需要装全部作业的文件夹和学生表在同一个文件夹下
check_one = function(loc1,hw)
{
  #需要安装包openxlsx
  library(openxlsx)
  #loc1 ,学生excel表的保存路径
  #获得它的学生excel根目录的保存路径
  loc_split = unlist(strsplit(loc1,split='/'))
  loc_split =loc_split[-length(unlist(strsplit(loc1,split='/')))]
  loc2 = paste(loc_split,collapse = '/')
  stu = read.xlsx(loc1)
  # hw = "hw1"  #第几次作业
  loc = paste(loc2,hw,"LIST.TXT",sep = '/')
  test = read.table(loc,stringsAsFactors = FALSE)
  test
  list_test =list()
  for (i in 1:(length(row(test))-2)){
    temp = test[i,1]
    temp_list = unlist(strsplit(temp,split='_'))
    list_test[i] = temp_list[1]
  }

  for (i in 1:length(row(stu[2]))){
    if (stu[2][i,1] %in% list_test == FALSE){
      print(stu[1][i,1])
    }
  }
}

